class Constant {

  static const BASE_URL = "http://10.1.1.45:3000/";

  static const USERNAME_PREF_KEY = "username";
  static const EMAIL_PREF_KEY = "email";
  static const TOKEN_PREF_KEY = "token";
  static const USER_ID_PREF_KEY = "userID";

}